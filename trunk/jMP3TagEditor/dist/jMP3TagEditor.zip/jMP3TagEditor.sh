#!/bin/bash
JAVA=java
CLASSPATH=jMP3TagEditor-1.0.0.jar
for f in lib/*.jar;
do
	CLASSPATH="$CLASSPATH:$f"
done
"$JAVA" -classpath $CLASSPATH com.mscg.jmp3.main.AppLaunch $@
